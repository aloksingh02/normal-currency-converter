import {convertCurrency} from "normal-currency-converter";

convertCurrency("USD", "INR", 5).then(res=>console.log(res));